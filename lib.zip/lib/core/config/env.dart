/// Configuration injectée au build, plus rien en dur dans le code.
///
///   flutter run --dart-define=API_BASE_URL=https://xxxx.ngrok-free.app/api/v1
///   flutter build apk --dart-define=API_BASE_URL=https://zemoz-api-oxtf.onrender.com/api/v1
class Env {
  static const String apiBaseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'https://82c0-2c0f-f0f8-60a-3100-40b3-ab26-e52b-bce4.ngrok-free.app/api/v1',
  );
}
