enum LoginMode {
  phone,
  email 
}