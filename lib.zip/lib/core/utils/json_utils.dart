Map<String, dynamic>? asMap(dynamic value) =>
    value is Map ? Map<String, dynamic>.from(value) : null;

String? asString(dynamic value) => value == null ? null : '$value';
