import 'package:petitpotopro/core/auth/auth_tokens.dart';
import 'package:petitpotopro/features/auth/data/models/auth_user_model.dart';

class AuthResultModel {
  const AuthResultModel({required this.tokens, this.user});

  final AuthTokens tokens;
  final AuthUserModel? user;

  factory AuthResultModel.fromBody(dynamic body) {
    final tokens = AuthTokens.tryFromBody(body);
    if (tokens == null) {
      throw const FormatException('Tokens introuvables dans la réponse de login.');
    }
    return AuthResultModel(tokens: tokens, user: AuthUserModel.tryFromBody(body));
  }
}
