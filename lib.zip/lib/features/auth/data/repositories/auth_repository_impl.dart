import 'package:dartz/dartz.dart';
import 'package:petitpotopro/core/errors/failure.dart';
import 'package:petitpotopro/core/errors/guard.dart';
import 'package:petitpotopro/core/network/api_dto.dart';
import 'package:petitpotopro/features/auth/data/datasources/auth_local_datasource.dart';
import 'package:petitpotopro/features/auth/data/datasources/auth_remote_datasource.dart';
import 'package:petitpotopro/features/auth/domain/entities/auth_user.dart';
import 'package:petitpotopro/features/auth/domain/repositories/auth_repository.dart';

class AuthRepositoryImpl implements AuthRepository {
  const AuthRepositoryImpl({required this.remote, required this.local});

  final AuthRemoteDataSource remote;
  final AuthLocalDataSource local;

  @override
  Future<Either<Failure, AuthUser>> login({
    required String identifier,
    required String password,
  }) =>
      guard<AuthUser>(() async {
        final result = await remote.login(
          SigninAccountDto(identifier: identifier, password: password),
        );

        // Les tokens d'abord : l'appel suivant en a besoin.
        await local.saveTokens(result.tokens);

        final user = result.user ?? await remote.currentUser();
        await local.saveUser(user);
        return user;
      });

  @override
  Future<Either<Failure, AuthUser?>> restoreSession() =>
      guard<AuthUser?>(() async {
        if (!await local.hasSession()) return null;
        return local.readUser();
      });

  @override
  Future<Either<Failure, void>> logout() => guard<void>(local.clear);
}
