import 'package:dio/dio.dart';
import 'package:petitpotopro/core/network/api_dto.dart';
import 'package:petitpotopro/core/network/api_interceptor.dart';
import 'package:petitpotopro/core/network/api_url.dart';
import 'package:petitpotopro/features/auth/data/models/auth_result_model.dart';
import 'package:petitpotopro/features/auth/data/models/auth_user_model.dart';

abstract class AuthRemoteDataSource {
  Future<AuthResultModel> login(SigninAccountDto dto);

  Future<AuthUserModel> currentUser();
}

class AuthRemoteDataSourceImpl implements AuthRemoteDataSource {
  const AuthRemoteDataSourceImpl(this._dio);

  final Dio _dio;

  @override
  Future<AuthResultModel> login(SigninAccountDto dto) async {
    final response = await _dio.post<dynamic>(
      ApiUrl.login,
      data: dto.toJson(),
      // Un 401 ici = mauvais identifiants, pas un token expiré : pas de refresh.
      options: Options(extra: {ApiInterceptor.skipAuthKey: true}),
    );
    return AuthResultModel.fromBody(response.data);
  }

  @override
  Future<AuthUserModel> currentUser() async {
    final response = await _dio.get<dynamic>(ApiUrl.currentUser);
    final user = AuthUserModel.tryFromBody(response.data);
    if (user == null) {
      throw const FormatException('Utilisateur introuvable dans la réponse.');
    }
    return user;
  }
}
