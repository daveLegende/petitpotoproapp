import 'package:dartz/dartz.dart';
import 'package:petitpotopro/core/errors/failure.dart';
import 'package:petitpotopro/features/auth/domain/entities/auth_user.dart';

abstract class AuthRepository {
  /// [identifier] : email ou téléphone.
  Future<Either<Failure, AuthUser>> login({
    required String identifier,
    required String password,
  });

  /// Lecture 100 % locale (aucun appel réseau) : `null` si pas de session.
  Future<Either<Failure, AuthUser?>> restoreSession();

  Future<Either<Failure, void>> logout();
}
