class Tournament {
  final String image;
  final String title;
  final String description;
  final String phase;

  const Tournament({
    required this.image,
    required this.title,
    required this.description,
    required this.phase,
  });
}

const tournaments = [
  Tournament(
    image: 'assets/images/onboarding/onboarding_1.png',
    title: 'Coupe de la Jeunesse',
    description: 'Les meilleures equipes se retrouvent pour une nouvelle saison.',
    phase: 'Phase de poule',
  ),
  Tournament(
    image: 'assets/images/onboarding/onboarding_2.png',
    title: 'Tournoi des Champions',
    description: 'Un duel intense entre les clubs les plus ambitieux.',
    phase: 'Demi-finale',
  ),
  Tournament(
    image: 'assets/images/onboarding/onboarding_3.png',
    title: 'Petit Poto Cup',
    description: 'La grande finale approche, les equipes jouent le titre.',
    phase: 'Finale',
  ),
];
