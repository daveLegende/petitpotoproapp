import 'package:flutter/material.dart';
import 'package:petitpotopro/common/helpers/style.dart';
import 'package:petitpotopro/core/configs/theme/app_colors.dart';

class _Tournament {
  final String image;
  final String title;
  final String description;
  final String phase;

  const _Tournament({
    required this.image,
    required this.title,
    required this.description,
    required this.phase,
  });
}

const _tournaments = [
  _Tournament(
    image: 'assets/images/onboarding/onboarding_1.png',
    title: 'Coupe de la Jeunesse',
    description: 'Les meilleures equipes se retrouvent pour une nouvelle saison.',
    phase: 'Phase de poule',
  ),
  _Tournament(
    image: 'assets/images/onboarding/onboarding_2.png',
    title: 'Tournoi des Champions',
    description: 'Un duel intense entre les clubs les plus ambitieux.',
    phase: 'Demi-finale',
  ),
  _Tournament(
    image: 'assets/images/onboarding/onboarding_3.png',
    title: 'Petit Poto Cup',
    description: 'La grande finale approche, les equipes jouent le titre.',
    phase: 'Finale',
  ),
];

class HomeScreen extends StatefulWidget {
  static const route = '/home';
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _searchController = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final filteredTournaments = _tournaments.where((tournament) {
      final query = _query.toLowerCase();
      return tournament.title.toLowerCase().contains(query) ||
          tournament.description.toLowerCase().contains(query) ||
          tournament.phase.toLowerCase().contains(query);
    }).toList();

    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
              sliver: SliverToBoxAdapter(
                child: Row(
                  children: [
                    Container(
                      width: 54,
                      height: 54,
                      padding: const EdgeInsets.all(9),
                      decoration: BoxDecoration(
                        color: AppColors.white,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: AppColors.primary, width: 1.5),
                      ),
                      child: Image.asset(
                        'assets/images/logo/logo.png',
                        fit: BoxFit.contain,
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Bonjour, passionne de foot', style: StyleText().caption),
                          const SizedBox(height: 3),
                          Text('Les tournois du moment', style: StyleText().subtitle),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: () {},
                      tooltip: 'Notifications',
                      icon: const Icon(Icons.notifications_none_rounded),
                      style: IconButton.styleFrom(
                        backgroundColor: AppColors.white,
                        foregroundColor: AppColors.neutral,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 24, 20, 20),
              sliver: SliverToBoxAdapter(
                child: TextField(
                  controller: _searchController,
                  onChanged: (value) => setState(() => _query = value.trim()),
                  textInputAction: TextInputAction.search,
                  decoration: const InputDecoration(
                    hintText: 'Rechercher un tournoi',
                    prefixIcon: Icon(Icons.search_rounded),
                    suffixIcon: Icon(Icons.tune_rounded),
                  ),
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
              sliver: SliverToBoxAdapter(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Tournois populaires', style: StyleText().headBlack),
                    Text('${filteredTournaments.length} resultats', style: StyleText().caption),
                  ],
                ),
              ),
            ),
            if (filteredTournaments.isEmpty)
              SliverFillRemaining(
                hasScrollBody: false,
                child: Center(
                  child: Text('Aucun tournoi trouve', style: StyleText().desc),
                ),
              )
            else
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                sliver: SliverList.builder(
                  itemCount: filteredTournaments.length,
                  itemBuilder: (context, index) => _TournamentCard(
                    tournament: filteredTournaments[index],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _TournamentCard extends StatelessWidget {
  final _Tournament tournament;

  const _TournamentCard({required this.tournament});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      elevation: 2,
      shadowColor: AppColors.neutral.withValues(alpha: 0.12),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              SizedBox(
                height: 156,
                width: double.infinity,
                child: Image.asset(tournament.image, fit: BoxFit.cover),
              ),
              Positioned(
                top: 12,
                right: 12,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
                  decoration: BoxDecoration(
                    color: AppColors.neutral.withValues(alpha: 0.84),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    tournament.phase,
                    style: const TextStyle(
                      color: AppColors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(tournament.title, style: StyleText().subtitle),
                const SizedBox(height: 7),
                Text(
                  tournament.description,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: StyleText().desc,
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    const Icon(Icons.sports_soccer_rounded,
                        size: 17, color: AppColors.primary),
                    const SizedBox(width: 6),
                    Text(tournament.phase, style: StyleText().captionBold),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}